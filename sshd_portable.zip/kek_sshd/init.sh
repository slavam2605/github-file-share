./bin/ssh-keygen -A
chmod g-w $(pwd)
chmod o-w $(pwd)
chmod 700 ~/.ssh
cp debugger_host_key ~/.ssh
chmod 600 ~/.ssh/debugger_host_key
touch sshd_log
sed -i -- "s~\$ROOT_FOLDER~$(pwd)~g" etc/sshd_config
