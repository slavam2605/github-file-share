echo >> sshd_log
date -R >> sshd_log
sudo $(pwd)/sbin/sshd -D -E sshd_log
